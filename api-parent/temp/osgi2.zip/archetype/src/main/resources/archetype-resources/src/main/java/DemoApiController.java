#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package};

import ${groupId}.api.ApiController;

public class DemoApiController extends ApiController {

	public DemoApiController() {
		addClass(DemoApiClass.class);
	}
}
