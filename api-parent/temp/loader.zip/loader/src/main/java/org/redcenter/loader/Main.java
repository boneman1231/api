package org.redcenter.loader;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map.Entry;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;

public class Main {

	public static void main(String[] args) {
		try {
			PropertiesConfiguration pc = new PropertiesConfiguration(
					"config.properties");
			// System.out.println(pc.getString("sss"));

			List<Object> tables = pc.getList("SOURCE_TABLE");
			for (Object table : tables) {
				String tableName = table.toString();
				process(tableName.toUpperCase(), pc);
			}
		} catch (ConfigurationException e) {
			e.printStackTrace();
		}
	}

	private static void process(String tableName, PropertiesConfiguration pc) {
		List<Object> columns = pc.getList(tableName + ".COLUMN");
		List<Object> exColumns = pc.getList(tableName + ".COLUMN.EXCLUDE");

		HashSet<String> source = new HashSet<String>();
		columns.removeAll(exColumns);
		for (Object column : columns) {
			System.out.println(column);
			source.add(column.toString());
		}

		HashMap<String, String> target = new HashMap<String, String>();
		for (String key : source) {
			target.put(key, key);
		}
						
		List<Object> mapping = pc.getList(tableName + ".COLUMN.MAPPING");
		for (Object m : mapping) {
			System.out.println(m);
			String s = m.toString().split("=")[0];
			String t = m.toString().split("=")[1];
			if (target.get(s) != null){
				target.put(s, t);
			}
		}

		System.out.println("============");
		boolean first = true;
		String query = "";
		String insert = "";
		for (Entry<String, String> entry : target.entrySet()) {
//			System.out.println(entry.getKey() + " => " + entry.getValue());			
			if (!first){
				query+=",";
				insert+=",";
			}
			query += "\""+entry.getKey() + "\"";
			insert += "\""+entry.getValue() + "\"";
			first =false;
		}
		
		System.out.println("Q: " + query);
		System.out.println("I: " + insert);
		
		String sql = "INSERT INTO " + tableName + " (c1,c2) VALUES (v1, v2)";

	}

	private static String getString() {
		return null;
	}
}
