package org.redcenter.jboss.security.ejb;

import javax.annotation.Resource;
import javax.annotation.security.RolesAllowed;
import javax.ejb.EJBContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class UserServices {
	@Resource
	private EJBContext ejbContext;

	@RolesAllowed("user")
	public String getPrincipalName() {
		return ejbContext.getCallerPrincipal().getName();
	}

	@PersistenceContext(name = "test")
	private EntityManager em;

	public void persist(UserEntity user) {
		em.persist(user);
	}

	public UserEntity find(long id) {
		return em.find(UserEntity.class, id);
	}
}
