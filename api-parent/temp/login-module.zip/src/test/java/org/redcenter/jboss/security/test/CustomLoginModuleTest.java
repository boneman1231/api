//package org.redcenter.jboss.security.test;
//
//import static org.junit.Assert.assertEquals;
//import static org.junit.Assert.assertTrue;
//
//import java.io.BufferedReader;
//import java.io.File;
//import java.io.FileReader;
//import java.io.IOException;
//import java.net.URL;
//import java.security.Principal;
//
//import org.jboss.arquillian.container.test.api.Deployment;
//import org.jboss.arquillian.junit.Arquillian;
//import org.jboss.arquillian.test.api.ArquillianResource;
//import org.jboss.as.cli.CommandContext;
//import org.jboss.as.cli.CommandContextFactory;
//import org.jboss.as.protocol.StreamUtils;
//import org.jboss.shrinkwrap.api.ShrinkWrap;
//import org.jboss.shrinkwrap.api.spec.WebArchive;
//import org.junit.AfterClass;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.redcenter.jboss.security.CustomUsernamePasswordLoginModule;
//import org.redcenter.jboss.security.ejb.LoginServlet;
//import org.redcenter.jboss.security.ejb.SampleEJB;
//import org.xml.sax.SAXException;
//
//import com.meterware.httpunit.GetMethodWebRequest;
//import com.meterware.httpunit.HttpException;
//import com.meterware.httpunit.WebConversation;
//import com.meterware.httpunit.WebResponse;
//
//@RunWith(Arquillian.class)
//public class CustomLoginModuleTest {
//
//	@ArquillianResource
//    private URL deployUrl;
//
//    @AfterClass
//    public static void removeSecurityDomain() {
//        processCliFile(new File("src/test/resources/jboss-remove-login-module.cli"));
//    }
//
//    @Deployment(testable = false)
//    public static WebArchive createDeployment() {
//        processCliFile(new File("src/test/resources/jboss-add-login-module.cli"));
//
//        WebArchive war = ShrinkWrap.create(WebArchive.class)
//                                   .addClass(CustomUsernamePasswordLoginModule.class)
//                                   .addClass(SampleEJB.class)
//                                   .addClass(LoginServlet.class)
//                                   .addAsWebInfResource("jboss-web.xml")
//                                   .addAsWebInfResource("jboss-ejb3.xml")
//                                   .addAsResource("users.properties")
//                                   .addAsResource("roles.properties");
//        System.out.println(war.toString(true));
//        return war;
//    }
//
//    @Test
//    public void testLogin() throws IOException, SAXException {
//        WebConversation webConversation = new WebConversation();
//        GetMethodWebRequest request = new GetMethodWebRequest(deployUrl + "LoginServlet");
//        request.setParameter("username", "username");
//        request.setParameter("password", "password");
//        WebResponse response = webConversation.getResponse(request);
//        assertTrue(response.getText().contains("principal=" + Principal.class.getSimpleName()));
//        assertTrue(response.getText().contains("username=username"));        
//        System.out.println(response.getText());
//    }
//
//    @Test
//    public void testInvalidLogin() throws IOException, SAXException {
//        try {
//            WebConversation webConversation = new WebConversation();
//            GetMethodWebRequest request = new GetMethodWebRequest(deployUrl + "LoginServlet");
//            request.setParameter("username", "invalid");
//            request.setParameter("password", "invalid");
//            webConversation.getResponse(request);
//            assertTrue(false);
//        } catch (HttpException e) {
//            assertEquals(403, e.getResponseCode());
//        }
//    }
//
//    private static void processCliFile(File file) {
//		// Initialize the CLI context
//		final CommandContext commandContext;
//		try {
//			commandContext = CommandContextFactory.getInstance()
//					.newCommandContext();
//		} catch (Exception e) {
//			throw new IllegalStateException("Failed to initialize CLI context",
//					e);
//		}
//
//		try {
//			// connect to the server controller
//			commandContext.connectController("localhost", 9999);
//
//			// read cli file
//			BufferedReader reader = null;
//			try {
//				reader = new BufferedReader(new FileReader(file));
//				String line = reader.readLine();
//				while (commandContext.getExitCode() == 0
//						&& !commandContext.isTerminated() && line != null) {
//					// execute commands and operations
//					System.out.println("CLI: " + line.trim());
//					commandContext.handleSafe(line.trim());
//					line = reader.readLine();
//				}
//			} catch (Throwable e) {
//				throw new IllegalStateException("Failed to process file '"
//						+ file.getAbsolutePath() + "'", e);
//			} finally {
//				StreamUtils.safeClose(reader);
//			}
//		} catch (Exception e) {
//			// the operation or the command has failed
//			e.printStackTrace();
//		} finally {
//			// terminate the session and
//			// close the connection to the controller
//			// commandContext.terminateSession();
//			closeCommandContext(commandContext);
//		}
//	}
//    
//	/**
//	 * Close the given command context properly to free allocated resources
//	 * (close the connection to the controller and terminate the session).
//	 * 
//	 * @param commandContext
//	 *            the command context to close
//	 */
//	private static void closeCommandContext(final CommandContext commandContext) {
//		if (commandContext != null) {
//			commandContext.disconnectController();
//			if (!commandContext.isTerminated()) {
//				commandContext.terminateSession();
//			}
//		}
//	}
//}
