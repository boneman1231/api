package org.redcenter.jboss.security.test;

import java.security.PrivilegedAction;

import javax.inject.Inject;
import javax.naming.InitialContext;
import javax.security.auth.Subject;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;

import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.arquillian.test.api.ArquillianResource;
import org.jboss.shrinkwrap.api.ArchivePaths;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.EmptyAsset;
import org.jboss.shrinkwrap.api.spec.JavaArchive;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.redcenter.jboss.security.CustomUsernamePasswordLoginModule;
import org.redcenter.jboss.security.ejb.SampleEJB;

@RunWith(Arquillian.class)
public class LoginTest {

	@ArquillianResource
	private InitialContext arquillianContext;

	@Inject
	private SampleEJB ejb;

	@Deployment
	public static JavaArchive createDeployment() {
		return ShrinkWrap
				.create(JavaArchive.class, "test2.jar")
				.addClasses(CustomUsernamePasswordLoginModule.class,
						JBossLoginContextFactory.class, SampleEJB.class)
				.addAsManifestResource(EmptyAsset.INSTANCE,
						ArchivePaths.create("beans.xml"))
				.addAsResource("users.properties")
				.addAsResource("roles.properties")
				.addAsManifestResource("jboss-ejb3.xml");
	}

	@Test
	public void testGetPrincipalName() {
		System.out.println("=====================testGetPrincipalName()");
		Exception ex = null;
		try {
			String name = ejb.getPrincipalName();
			System.out.println("ejb.getPrincipalName(): "+name);
		} catch (Exception e) {
			ex = e;
		}
		Assert.assertNotNull(ex);
	}

	@Test
	public void testAuthorised() throws LoginException {
		System.out.println("=====================testGetPrincipalNameAuth()");
		LoginContext loginContext = JBossLoginContextFactory
				.createLoginContext("username", "USERNAME");
		loginContext.login();
		try {
			Subject.doAs(loginContext.getSubject(),
					new PrivilegedAction<Void>() {
						public Void run() {
							String name = ejb.getPrincipalName();
							Assert.assertEquals("username", name);
							return null;
						}
					});
		} finally {
			loginContext.logout();
		}
	}
}
