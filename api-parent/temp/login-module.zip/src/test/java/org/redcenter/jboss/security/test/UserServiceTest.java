package org.redcenter.jboss.security.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.security.PrivilegedAction;

import javax.inject.Inject;
import javax.naming.InitialContext;
import javax.security.auth.Subject;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;

import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.arquillian.test.api.ArquillianResource;
import org.jboss.as.cli.CommandContext;
import org.jboss.as.cli.CommandContextFactory;
import org.jboss.as.protocol.StreamUtils;
import org.jboss.shrinkwrap.api.ArchivePaths;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.EmptyAsset;
import org.jboss.shrinkwrap.api.spec.JavaArchive;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.redcenter.jboss.security.CustomUsernamePasswordLoginModule;
import org.redcenter.jboss.security.ejb.UserEntity;
import org.redcenter.jboss.security.ejb.UserServices;

@RunWith(Arquillian.class)
public class UserServiceTest {

	@ArquillianResource
	private InitialContext arquillianContext;

	@Inject
	private UserServices service;

	// @AfterClass
	// public static void removeSecurityDomain() {
	// processCliFile(new File(
	// "src/test/resources/jboss-remove-login-module.cli"));
	// }

	// @Deployment(testable = false)
	@Deployment
	public static JavaArchive createDeployment() {
		// processCliFile(new
		// File("src/test/resources/jboss-add-login-module.cli"));

		return ShrinkWrap
				.create(JavaArchive.class, "test.jar")
				.addClasses(CustomUsernamePasswordLoginModule.class,
						JBossLoginContextFactory.class, UserEntity.class,
						UserServices.class)
				.addAsManifestResource("test-persistence.xml",
						"persistence.xml")
				.addAsManifestResource(EmptyAsset.INSTANCE,
						ArchivePaths.create("beans.xml"))
				.addAsResource("users.properties")
				.addAsResource("roles.properties");
	}

	@Test
	public void testGetUser() {
		System.out.println("============================testGetUser()");
		UserEntity theUser = new UserEntity();
		theUser.setUsername("cchungu");
		service.persist(theUser);

		UserEntity testSimpleUser = service.find(theUser.getId());
		Assert.assertEquals("cchungu", testSimpleUser.getUsername());
	}

	@Test
	public void testGetPrincipalName() {
		System.out.println("======================testGetPrincipalName()");
		String name = service.getPrincipalName();
		Assert.assertEquals("anonymous", name);
	}

	@Test
	public void testAuthorised() throws LoginException {
		LoginContext loginContext = JBossLoginContextFactory
				.createLoginContext("user1", "password");
		loginContext.login();
		try {
			Subject.doAs(loginContext.getSubject(),
					new PrivilegedAction<Void>() {
						public Void run() {
							String name = service.getPrincipalName();
							Assert.assertEquals("user1", name);
							return null;
						}
					});
		} finally {
			loginContext.logout();
		}
	}

	// private static void processCliFile(File file) {
	// // Initialize the CLI context
	// final CommandContext commandContext;
	// try {
	// commandContext = CommandContextFactory.getInstance()
	// .newCommandContext();
	// } catch (Exception e) {
	// throw new IllegalStateException("Failed to initialize CLI context",
	// e);
	// }
	//
	// try {
	// // connect to the server controller
	// commandContext.connectController("localhost", 9999);
	//
	// // read cli file
	// BufferedReader reader = null;
	// try {
	// reader = new BufferedReader(new FileReader(file));
	// String line = reader.readLine();
	// while (commandContext.getExitCode() == 0
	// && !commandContext.isTerminated() && line != null) {
	// // execute commands and operations
	// System.out.println("CLI: " + line.trim());
	// commandContext.handleSafe(line.trim());
	// line = reader.readLine();
	// }
	// } catch (Throwable e) {
	// throw new IllegalStateException("Failed to process file '"
	// + file.getAbsolutePath() + "'", e);
	// } finally {
	// StreamUtils.safeClose(reader);
	// }
	// } catch (Exception e) {
	// // the operation or the command has failed
	// e.printStackTrace();
	// } finally {
	// // terminate the session and
	// // close the connection to the controller
	// // commandContext.terminateSession();
	// closeCommandContext(commandContext);
	// }
	// }

	// /**
	// * Close the given command context properly to free allocated resources
	// * (close the connection to the controller and terminate the session).
	// *
	// * @param commandContext
	// * the command context to close
	// */
	// private static void closeCommandContext(final CommandContext
	// commandContext) {
	// if (commandContext != null) {
	// commandContext.disconnectController();
	// if (!commandContext.isTerminated()) {
	// commandContext.terminateSession();
	// }
	// }
	// }
}
